/** lcd.h
 *  \brief mbed library for XPT2046 SPI LCD Controller (TFT_320QVT module).
 *  \copyright GNU Public License, v2. or later
 *
 * Copyright (C)2023 Jing-Jia Liou. All right reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to:
 *
 * Free Software Foundation, Inc.
 * 51 Franklin St, 5th Floor, Boston, MA 02110-1301, USA
 *
 *********************************************************************/

#include "mbed.h"

#ifndef LCD_H
#define LCD_H

#ifdef __cplusplus
extern "C" {
#endif


#define PORTRAIT            0
#define LANDSCAPE           1

#define LCD_X 320
#define LCD_Y 480

class LCD
{
    public:

        //CS  RESET DC/RS  SDI/MOSI  SCK  SDO/MISO
        //          DC=1 default for data mode
        LCD(PinName CS, PinName RESET, PinName DC, PinName MOSI, PinName SCK, PinName MISO);


        void InitLCD(uint8_t orientation = LANDSCAPE);
        void Address_set(unsigned int x1, unsigned int y1, unsigned int x2, unsigned int y2);
        void FillRectangle(unsigned int x, unsigned int y, unsigned int w, unsigned int h, unsigned int c);
        void FillArea(uint16_t x1, uint16_t y1, uint16_t x2, uint16_t y2, uint16_t* color_p);
        void DrawPixel(uint16_t color);
        void LCD_Clear(unsigned int j);
        void H_line(unsigned int x, unsigned int y, unsigned int l, unsigned int c);
        void V_line(unsigned int x, unsigned int y, unsigned int l, unsigned int c);
        void Rect(unsigned int x,unsigned int y,unsigned int w,unsigned int h,unsigned int c);
    
    protected:

        inline void Lcd_Write_Bus(unsigned char d){
            spi.write(d);
        }

        inline void Lcd_Write_Com(unsigned char VH){   
            dc=0;
            Lcd_Write_Bus(VH);
            dc=1;
        }

        inline void Lcd_Write_Data(unsigned char VH){
            Lcd_Write_Bus(VH);
        }

        SPI spi; // SPI master object: mosi, miso, sclk
        DigitalOut dc;   //data or command mode
        DigitalOut reset ; //reset signal
        DigitalOut cs ;   //chip select
        int8_t orient; //Not used
};

#ifdef __cplusplus
}
#endif

#endif
