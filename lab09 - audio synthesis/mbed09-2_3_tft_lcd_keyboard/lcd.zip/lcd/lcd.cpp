#include "lcd.h"

LCD::LCD(PinName CS, PinName RESET, PinName DC, PinName MOSI, PinName SCK,
         PinName MISO)
    : cs(CS), reset(RESET), dc(DC), spi(MOSI, MISO, SCK) {
  reset = 1;
  dc = 1;
  cs = 1;
  spi.format(8, 0);
  spi.frequency(8000000);
}

void LCD::InitLCD(uint8_t orientation) {
  orient = orientation;
  reset = 1;
  wait_us(5000);
  reset = 0;
  wait_us(15000);
  reset = 1;
  wait_us(15000);

  cs = 0; // CS

  Lcd_Write_Com(0xF0);
  Lcd_Write_Data(0xC3);
  Lcd_Write_Com(0xF0);
  Lcd_Write_Data(0x96);
  Lcd_Write_Com(0x36);
  Lcd_Write_Data(0x68);
  Lcd_Write_Com(0x3A);
  Lcd_Write_Data(0x05);
  Lcd_Write_Com(0xB0);
  Lcd_Write_Data(0x80);
  Lcd_Write_Com(0xB6);
  Lcd_Write_Data(0x00);
  Lcd_Write_Data(0x02);
  Lcd_Write_Com(0xB5);
  Lcd_Write_Data(0x02);
  Lcd_Write_Data(0x03);
  Lcd_Write_Data(0x00);
  Lcd_Write_Data(0x04);
  Lcd_Write_Com(0xB1);
  Lcd_Write_Data(0x80);
  Lcd_Write_Data(0x10);
  Lcd_Write_Com(0xB4);
  Lcd_Write_Data(0x00);
  Lcd_Write_Com(0xB7);
  Lcd_Write_Data(0xC6);
  Lcd_Write_Com(0xC5);
  Lcd_Write_Data(0x24);
  Lcd_Write_Com(0xE4);
  Lcd_Write_Data(0x31);
  Lcd_Write_Com(0xE8);
  Lcd_Write_Data(0x40);
  Lcd_Write_Data(0x8A);
  Lcd_Write_Data(0x00);
  Lcd_Write_Data(0x00);
  Lcd_Write_Data(0x29);
  Lcd_Write_Data(0x19);
  Lcd_Write_Data(0xA5);
  Lcd_Write_Data(0x33);
  Lcd_Write_Com(0xC2);
  Lcd_Write_Com(0xA7);

  Lcd_Write_Com(0xE0);
  Lcd_Write_Data(0xF0);
  Lcd_Write_Data(0x09);
  Lcd_Write_Data(0x13);
  Lcd_Write_Data(0x12);
  Lcd_Write_Data(0x12);
  Lcd_Write_Data(0x2B);
  Lcd_Write_Data(0x3C);
  Lcd_Write_Data(0x44);
  Lcd_Write_Data(0x4B);
  Lcd_Write_Data(0x1B);
  Lcd_Write_Data(0x18);
  Lcd_Write_Data(0x17);
  Lcd_Write_Data(0x1D);
  Lcd_Write_Data(0x21);

  Lcd_Write_Com(0XE1);
  Lcd_Write_Data(0xF0);
  Lcd_Write_Data(0x09);
  Lcd_Write_Data(0x13);
  Lcd_Write_Data(0x0C);
  Lcd_Write_Data(0x0D);
  Lcd_Write_Data(0x27);
  Lcd_Write_Data(0x3B);
  Lcd_Write_Data(0x44);
  Lcd_Write_Data(0x4D);
  Lcd_Write_Data(0x0B);
  Lcd_Write_Data(0x17);
  Lcd_Write_Data(0x17);
  Lcd_Write_Data(0x1D);
  Lcd_Write_Data(0x21);

  Lcd_Write_Com(0X36);
  Lcd_Write_Data(0x48);
  Lcd_Write_Com(0xF0);
  Lcd_Write_Data(0xC3);
  Lcd_Write_Com(0xF0);
  Lcd_Write_Data(0x69);
  Lcd_Write_Com(0X13);
  Lcd_Write_Com(0X11);
  wait_us(120000);
  Lcd_Write_Com(0X29);

  cs = 1;
}

void LCD::Address_set(unsigned int x1, unsigned int y1, unsigned int x2,
                      unsigned int y2) {
  Lcd_Write_Com(0x2a);
  Lcd_Write_Data(x1 >> 8);
  Lcd_Write_Data(x1);
  Lcd_Write_Data(x2 >> 8);
  Lcd_Write_Data(x2);
  Lcd_Write_Com(0x2b);
  Lcd_Write_Data(y1 >> 8);
  Lcd_Write_Data(y1);
  Lcd_Write_Data(y2 >> 8);
  Lcd_Write_Data(y2);
  Lcd_Write_Com(0x2c);
}

//Fill a single color rectangle
void LCD::FillRectangle(unsigned int x, unsigned int y, unsigned int w,
                        unsigned int h, unsigned int c) {
  cs = 0;
  Address_set(x, y, x + w, y + h);
  unsigned int count = (h+1) * (w+1);
  for (unsigned i = 0; i < count; i++) {
    Lcd_Write_Data(c >> 8 & 0xFF);
    Lcd_Write_Data(c & 0xFF);
    // Lcd_Write_Data((c>>8)&0xF8);
    // Lcd_Write_Data((c>>3)&0xFC);
    // Lcd_Write_Data(c<<3);
  }
  cs = 1;
}

// Draw a pixel at current x, y
void LCD::DrawPixel(uint16_t color) {
  cs = 0;
  Lcd_Write_Data(color >> 8 & 0xFF);
  Lcd_Write_Data(color & 0xFF);
  cs = 1;
}

// Fill an area with a pixel array color_p with RGB565 (16bit)
void LCD::FillArea(uint16_t x1, uint16_t y1, uint16_t x2, uint16_t y2,
                   uint16_t *color_p) {
  cs = 0;
  uint16_t c16bit;
  Address_set(x1, y1, x2, y2);
  for (int16_t i = y1; i <= y2; i++) {
    for (int16_t j = x1; j <= x2; j++) {
      // Put a pixel *color_p at x+j, y+i
      c16bit = (*color_p);
      Lcd_Write_Data(c16bit >> 8 & 0xFF);
      Lcd_Write_Data(c16bit & 0xFF);
      color_p++;
    }
  }
  cs = 1;
}

void LCD::LCD_Clear(unsigned int j) {
  unsigned int i, m;
  cs = 0;
  Address_set(0, 0, 320, 480);
  for (i = 0; i < 320; i++)
    for (m = 0; m < 480; m++) {
      Lcd_Write_Data(j >> 8 & 0xFF);
      Lcd_Write_Data(j & 0xFF);
      // Lcd_Write_Data((j>>8)&0xF8);
      // Lcd_Write_Data((j>>3)&0xFC);
      // Lcd_Write_Data(j<<3);
    }
  cs = 1;
}

void LCD::H_line(unsigned int x, unsigned int y, unsigned int l,
                 unsigned int c) {
  unsigned int i, j;
  cs = 0;
  Lcd_Write_Com(0x02c); // write_memory_start
  dc = 1;
  l = l + x;
  Address_set(x, y, l, y);
  j = l * 2;
  for (i = 1; i <= j; i++) {
    Lcd_Write_Data((c >> 8) & 0xF8);
    Lcd_Write_Data((c >> 3) & 0xFC);
    Lcd_Write_Data(c << 3);
  }
  cs = 1;
}

void LCD::V_line(unsigned int x, unsigned int y, unsigned int l,
                 unsigned int c) {
  unsigned int i, j;
  cs = 0;
  Lcd_Write_Com(0x02c); // write_memory_start
  dc = 1;
  l = l + y;
  Address_set(x, y, x, l);
  j = l * 2;
  for (i = 1; i <= j; i++) {
    Lcd_Write_Data((c >> 8) & 0xF8);
    Lcd_Write_Data((c >> 3) & 0xFC);
    Lcd_Write_Data(c << 3);
  }
  cs = 1;
}

void LCD::Rect(unsigned int x, unsigned int y, unsigned int w, unsigned int h,
               unsigned int c) {
  H_line(x, y, w, c);
  H_line(x, y + h, w, c);
  V_line(x, y, h, c);
  V_line(x + w, y, h, c);
}
