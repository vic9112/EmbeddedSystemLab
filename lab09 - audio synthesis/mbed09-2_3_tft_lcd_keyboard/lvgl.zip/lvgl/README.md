# lvgl 7.11 library source code with template setup for 4.0 TFT module

Original GitHub release: https://github.com/lvgl/lvgl/releases/tag/v7.11.0
