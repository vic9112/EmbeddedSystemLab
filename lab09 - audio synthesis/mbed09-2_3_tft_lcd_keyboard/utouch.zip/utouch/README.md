# utouch library of resistive touch interface for TFT module.
