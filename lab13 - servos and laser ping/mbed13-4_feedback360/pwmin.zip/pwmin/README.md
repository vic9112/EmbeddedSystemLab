# pwmin

A library to measure PWM signals.

Original version link: https://os.mbed.com/teams/PRJ1401_LIDAR/code/PwmIn/
Line 26 and 27 are changed.
